This crack is free to use.
Please DO NOT SELL IT ANYWHERE.
Thank you for downloading.





------------------------


TO UPDATE THE CRACK:

------------------------

Simply change the "5.1.00" to the version you want.
If it doesn't work, ctrl c and ctrl v the bat files.
Like this.



 (right click it on both and Edit)
------------------------------------------------------------------

LEGAL Live2D.bat file	+ 	Crack.
Ctrl c + v them in a visible place.


LEFT SIDE			RIGHT SIDE
------------------------||----------------------------------------
			||
LEGAL Bat file		||	the crack bat
			||	
------------------------||----------------------------------------
------------------------||----------------------------------------
			||
Copy the contents	||
in the legal bat files	||	Paste them here.
			||	
------------------------||----------------------------------------
------------------------||----------------------------------------
			||
LEGAL Bat files		||
(all content)		||	Locate "rlm1501.jar" and replace it with "rlm1501_mod.jar",
			||	SAID JAR FILE MUST BE LOCATED INTO THE app/lib ROUTE.
			||	
------------------------||----------------------------------------
------------------------||----------------------------------------
			||
LEGAL Bat files		||
(all content)		||	Once replaced, ctrl+s to save
			||	
------------------------||----------------------------------------
------------------------||----------------------------------------

Close both. If you didn't understand, you can reach me by email: lumeshinzou@gmail.com
Please specify your reason for contacting me, beforehand or you'll be ignored.

Repeat the process for all the 3 bat(s) left.
Place them into the Live2D folder. The rlm1501_mod.jar file provided must be located in Live2D's
installation folder, in app/lib route.

------------------------||----------------------------------------